const Booking = require("../models/Booking");
const Payment = require("../models/Payment");
const Room = require("../models/Room");
const DailyReport = require("../models/DailyReport");
const Kyc = require("../models/Kyc");
const ProcessTracker = require("../models/ProcessTracker");
const Transaction = require("../models/Transaction");

exports.generateDailyReport = async (req, res) => {
  try {
    const start = new Date();
    start.setHours(0, 0, 0, 0);

    const end = new Date();
    end.setHours(23, 59, 59, 999);

    // BOOKINGS
    const bookings = await Booking.find({
      createdAt: { $gte: start, $lte: end }
    });

    const payments = await Payment.find({
      createdAt: { $gte: start, $lte: end },
      status: "PAID"
    });

    const totalRooms = await Room.countDocuments();

    const report = {
      date: start,

      bookings: {
        total: bookings.length,
        confirmed: bookings.filter(b => b.status === "CONFIRMED").length,
        cancelled: bookings.filter(b => b.status === "CANCELLED").length
      },

      checkInOut: {
        checkedIn: bookings.filter(b => b.status === "CHECKED_IN").length,
        checkedOut: bookings.filter(b => b.status === "CHECKED_OUT").length
      },

      occupancy: {
        totalRooms,
        occupiedRooms: bookings.filter(b => b.status === "CHECKED_IN").length
      },

      revenue: {
        total: payments.reduce((a, b) => a + (b.amount || 0), 0),
        cash: payments.filter(p => p.method === "CASH").reduce((a, b) => a + (b.amount || 0), 0),
        upi: payments.filter(p => p.method === "UPI").reduce((a, b) => a + (b.amount || 0), 0),
        razorpay: payments.filter(p => p.method === "RAZORPAY").reduce((a, b) => a + (b.amount || 0), 0),
        bank: payments.filter(p => p.method === "BANK_TRANSFER").reduce((a, b) => a + (b.amount || 0), 0)
      },

      pendingPayments: bookings.filter(b => b.paymentStatus !== "PAID").length,

      generatedBy: req.user.id
    };

    await DailyReport.findOneAndUpdate(
      { date: start },
      report,
      { upsert: true }
    );

    res.json({
      message: "Daily report generated",
      report
    });
  } catch (error) {
    console.error("Error generating daily report:", error);
    res.status(500).json({ message: error.message || "Error generating report" });
  }
};


exports.getDailyReport = async (req, res) => {
  try {
    const date = new Date(req.params.date);
    date.setHours(0, 0, 0, 0);

    const report = await DailyReport.findOne({ date });

    if (!report) {
      return res.status(404).json({ message: "Report not found" });
    }

    res.json(report);
  } catch (error) {
    console.error("Error fetching daily report:", error);
    res.status(500).json({ message: error.message || "Error fetching report" });
  }
};

// ================= DASHBOARD STATS =================
exports.getDashboardStats = async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const endOfToday = new Date(today);
    endOfToday.setHours(23, 59, 59, 999);

    // Today's check-ins
    const todaysCheckIns = await Booking.countDocuments({
      status: "CHECKED_IN",
      checkIn: { $gte: today, $lte: endOfToday }
    });

    // Today's check-outs
    const todaysCheckOuts = await Booking.countDocuments({
      status: "CHECKED_OUT",
      checkOut: { $gte: today, $lte: endOfToday }
    });

    // Pending KYC
    const pendingKyc = await Kyc.countDocuments({
      kycStatus: "PENDING"
    });

    // Open tasks
    const openTasks = await ProcessTracker.countDocuments({
      status: { $in: ["OPEN", "ASSIGNED", "IN_PROGRESS"] }
    });

    // Active bookings (CONFIRMED or CHECKED_IN)
    const activeBookings = await Booking.countDocuments({
      status: { $in: ["CONFIRMED", "CHECKED_IN"] }
    });

    // Today's revenue
    const todaysPayments = await Payment.find({
      createdAt: { $gte: today, $lte: endOfToday },
      status: "PAID"
    });
    const todaysRevenue = todaysPayments.reduce((sum, payment) => sum + (payment.amount || 0), 0);

    res.json({
      todaysCheckIns,
      todaysCheckOuts,
      pendingKyc,
      openTasks,
      activeBookings,
      todaysRevenue
    });
  } catch (error) {
    console.error("Error fetching dashboard stats:", error);
    res.status(500).json({ message: error.message || "Error fetching dashboard stats" });
  }
};

// ================= RECENT ACTIVITY =================
exports.getRecentActivity = async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10;

    // Get recent bookings
    const recentBookings = await Booking.find()
      .populate("roomId", "roomNumber")
      .populate("userId", "phone name")
      .sort({ createdAt: -1 })
      .limit(limit)
      .lean();

    // Get recent payments
    const recentPayments = await Payment.find()
      .populate("bookingId", "confirmationNumber")
      .sort({ createdAt: -1 })
      .limit(limit)
      .lean();

    // Get recent check-ins
    const recentCheckIns = await Booking.find({ status: "CHECKED_IN" })
      .populate("roomId", "roomNumber")
      .populate("userId", "phone name")
      .sort({ checkIn: -1 })
      .limit(limit)
      .lean();

    // Combine and format activities
    const activities = [];

    recentBookings.forEach(booking => {
      activities.push({
        type: "BOOKING",
        icon: "🏨",
        title: "New booking created",
        description: `Room ${booking.roomId?.roomNumber || "N/A"} - ${booking.confirmationNumber || booking._id.toString().slice(-8)}`,
        timestamp: booking.createdAt,
        bookingId: booking._id
      });
    });

    recentCheckIns.forEach(booking => {
      activities.push({
        type: "CHECK_IN",
        icon: "✅",
        title: "Guest checked in",
        description: `Room ${booking.roomId?.roomNumber || "N/A"}`,
        timestamp: booking.checkIn || booking.updatedAt,
        bookingId: booking._id
      });
    });

    recentPayments.forEach(payment => {
      activities.push({
        type: "PAYMENT",
        icon: "💰",
        title: "Payment received",
        description: `₹${payment.amount || 0}`,
        timestamp: payment.createdAt,
        paymentId: payment._id
      });
    });

    // Sort by timestamp and limit
    activities.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    const limitedActivities = activities.slice(0, limit);

    res.json(limitedActivities);
  } catch (error) {
    console.error("Error fetching recent activity:", error);
    res.status(500).json({ message: error.message || "Error fetching recent activity" });
  }
};
