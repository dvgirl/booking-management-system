const Process = require("../models/ProcessTracker");
const Log = require("../models/ProcessLog");

exports.createProcess = async (req, res) => {
    const process = await Process.create({
        ...req.body,
        createdBy: req.user.id,
        isOffline: req.body.isOffline
    });

    await Log.create({
        processId: process._id,
        action: "CREATED",
        newStatus: process.status,
        performedBy: req.user.id
    });

    res.json(process);
};

exports.assignProcess = async (req, res) => {
    const process = await Process.findByIdAndUpdate(
        req.params.id,
        {
            assignedTo: req.body.assignedTo,
            status: "ASSIGNED"
        },
        { new: true }
    );

    await Log.create({
        processId: process._id,
        action: "ASSIGNED",
        newStatus: "ASSIGNED",
        performedBy: req.user.id
    });

    res.json(process);
};

exports.updateStatus = async (req, res) => {
    const process = await Process.findById(req.params.id);

    await Log.create({
        processId: process._id,
        action: "STATUS_UPDATED",
        oldStatus: process.status,
        newStatus: req.body.status,
        performedBy: req.user.id
    });

    process.status = req.body.status;
    await process.save();

    res.json(process);
};

exports.closeProcess = async (req, res) => {
    const process = await Process.findById(req.params.id);

    process.status = "CLOSED";
    process.closedBy = req.user.id;
    process.resolutionNote = req.body.resolutionNote;

    await process.save();

    await Log.create({
        processId: process._id,
        action: "CLOSED",
        newStatus: "CLOSED",
        performedBy: req.user.id
    });

    res.json({ message: "Process closed" });
};

