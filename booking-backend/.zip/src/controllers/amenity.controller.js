const Amenity = require("../models/Amenity");

exports.addAmenity = async (req, res) => {
  const amenity = await Amenity.create({
    name: req.body.name,
    virtualAccountId: req.user.virtualAccountId
  });

  res.json({
    message: "Amenity added",
    amenity
  });
};

exports.listAmenities = async (req, res) => {
  const amenities = await Amenity.find({
    virtualAccountId: req.user.virtualAccountId,
    isActive: true
  });

  res.json(amenities);
};
