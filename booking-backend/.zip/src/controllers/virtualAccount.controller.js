const VirtualAccount = require("../models/VirtualAccount");
const User = require("../models/User");


exports.createVirtualAccount = async (req, res) => {
  const { name } = req.body;

  const account = await VirtualAccount.create({
    name,
    code: "VA-" + Date.now(),
    createdBy: req.user.id
  });

  res.json({
    message: "Virtual account created",
    account
  });
};



exports.assignAdmin = async (req, res) => {
  const { adminId, virtualAccountId } = req.body;

  const admin = await User.findByIdAndUpdate(
    adminId,
    { virtualAccountId, role: "ADMIN" },
    { new: true }
  );

  res.json({
    message: "Admin assigned to virtual account",
    admin
  });
};
