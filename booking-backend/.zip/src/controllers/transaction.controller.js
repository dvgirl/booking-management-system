const Transaction = require("../models/Transaction");

exports.createTransaction = async (req, res) => {
    const {
        bookingId,
        amount,
        paymentMode,
        transactionType,
        transactionRef,
        isOffline,
        remarks
    } = req.body;

    const txn = await Transaction.create({
        bookingId,
        userId: req.user.id,
        amount,
        paymentMode,
        transactionType,
        transactionRef,
        isOffline,
        remarks,
        status: isOffline ? "PENDING" : "SUCCESS"
    });

    res.json({
        message: "Transaction created",
        transaction: txn
    });
};

exports.uploadProof = async (req, res) => {
    const txn = await Transaction.findById(req.params.id);

    txn.proofUrl = req.file.path;
    txn.status = "SUCCESS";
    await txn.save();

    res.json(txn);
};

exports.verifyTransaction = async (req, res) => {
    const txn = await Transaction.findByIdAndUpdate(
        req.params.id,
        {
            status: "VERIFIED",
            verifiedBy: req.user.id
        },
        { new: true }
    );

    res.json(txn);
};

exports.lockTransaction = async (req, res) => {
    const txn = await Transaction.findById(req.params.id);

    if (txn.locked) {
        return res.status(400).json({ message: "Already locked" });
    }

    txn.locked = true;
    await txn.save();

    res.json({ message: "Transaction locked permanently" });
};

exports.listTransactions = async (req, res) => {
    const filters = req.query;

    const txns = await Transaction.find(filters)
        .populate("bookingId userId verifiedBy");

    res.json(txns);
};
exports.createPayment = async (req, res) => {
    const txn = await Transaction.create({
        bookingId: req.body.bookingId,
        userId: req.user.id,
        amount: req.body.amount,
        direction: "IN",
        paymentMode: req.body.paymentMode,
        transactionRef: req.body.transactionRef,
        isOffline: req.body.isOffline,
        status: req.body.isOffline ? "PENDING" : "SUCCESS"
    });

    res.json(txn);
};
exports.createRefund = async (req, res) => {
    const originalTxn = await Transaction.findById(req.body.refundOf);

    if (!originalTxn || originalTxn.status !== "VERIFIED") {
        return res.status(400).json({ message: "Invalid original transaction" });
    }

    const refund = await Transaction.create({
        bookingId: originalTxn.bookingId,
        userId: originalTxn.userId,
        amount: req.body.amount,
        direction: "OUT",
        paymentMode: req.body.paymentMode, // DIFFERENT MODE ALLOWED
        transactionRef: req.body.transactionRef,
        isOffline: req.body.isOffline,
        refundOf: originalTxn._id,
        status: "PENDING",
        remarks: req.body.remarks
    });

    res.json(refund);
};



