const razorpay = require("../config/razorpay");
const Payment = require("../models/Payment");
const Booking = require("../models/Booking");
const crypto = require("crypto");


exports.createRazorpayOrder = async (req, res) => {
    const { bookingId } = req.body;

    const booking = await Booking.findById(bookingId);
    if (!booking) return res.status(404).json({ message: "Booking not found" });

    const order = await razorpay.orders.create({
        amount: booking.totalAmount * 100,
        currency: "INR",
        receipt: "rcpt_" + bookingId
    });

    await Payment.create({
        bookingId,
        amount: booking.totalAmount,
        method: "RAZORPAY",
        status: "PENDING",
        transactionRef: order.id,
        createdBy: req.user.id
    });

    res.json(order);
};


exports.verifyRazorpayPayment = async (req, res) => {
    const {
        razorpay_order_id,
        razorpay_payment_id,
        razorpay_signature
    } = req.body;

    const sign = razorpay_order_id + "|" + razorpay_payment_id;

    const expected = crypto
        .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
        .update(sign)
        .digest("hex");

    if (expected !== razorpay_signature) {
        return res.status(400).json({ message: "Invalid payment signature" });
    }

    await Payment.findOneAndUpdate(
        { transactionRef: razorpay_order_id },
        {
            status: "PAID",
            transactionRef: razorpay_payment_id
        }
    );

    res.json({ message: "Payment verified" });
};

exports.recordOfflinePayment = async (req, res) => {
    const { bookingId, amount, method, transactionRef } = req.body;

    await Payment.create({
        bookingId,
        amount,
        method,
        status: "PAID",
        transactionRef,
        createdBy: req.user.id
    });

    await Booking.findByIdAndUpdate(bookingId, {
        paymentStatus: "PAID"
    });

    res.json({ message: "Offline payment recorded" });
};

exports.uploadPaymentProof = async (req, res) => {
    await Payment.findByIdAndUpdate(req.params.id, {
        proofUrl: req.file.path
    });

    res.json({ message: "Proof uploaded" });
};
