const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth.middleware");
const role = require("../middleware/role.middleware");

const {
  generateDailyReport,
  getDailyReport,
  getDashboardStats,
  getRecentActivity
} = require("../controllers/report.controller");

router.post(
  "/generate",
  auth,
  role("SUPER_ADMIN"),
  generateDailyReport
);

router.get(
  "/:date",
  auth,
  role("SUPER_ADMIN"),
  getDailyReport
);

router.get(
  "/dashboard/stats",
  auth,
  getDashboardStats
);

router.get(
  "/dashboard/activity",
  auth,
  getRecentActivity
);

module.exports = router;
