const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth.middleware");
const role = require("../middleware/role.middleware");
const upload = require("../middleware/upload.middleware");

const {
  createRazorpayOrder,
  verifyRazorpayPayment,
  recordOfflinePayment,
  uploadPaymentProof
} = require("../controllers/payment.controller");

router.post("/razorpay/order", auth, createRazorpayOrder);
router.post("/razorpay/verify", auth, verifyRazorpayPayment);

router.post(
  "/offline",
  auth,
  role("ADMIN", "SUPER_ADMIN"),
  recordOfflinePayment
);

router.post(
  "/proof/:id",
  auth,
  role("ADMIN", "SUPER_ADMIN"),
  upload.single("proof"),
  uploadPaymentProof
);

module.exports = router;
