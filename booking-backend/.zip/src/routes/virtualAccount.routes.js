const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth.middleware");
const role = require("../middleware/role.middleware");

const {
  createVirtualAccount,
  assignAdmin
} = require("../controllers/virtualAccount.controller");

router.post(
  "/",
  auth,
  role("SUPER_ADMIN"),
  createVirtualAccount
);

router.post(
  "/assign-admin",
  auth,
  role("SUPER_ADMIN"),
  assignAdmin
);

module.exports = router;
