const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth.middleware");
const role = require("../middleware/role.middleware");
const { addAmenity, listAmenities } = require("../controllers/amenity.controller");

router.post("/", auth, role("ADMIN"), addAmenity);
router.get("/", auth, role("ADMIN"), listAmenities);

module.exports = router;
