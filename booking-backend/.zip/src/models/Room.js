const mongoose = require("mongoose");

const roomSchema = new mongoose.Schema({
  roomNumber: {
    type: Number,
    required: true,
    unique: true
  },
  type: {
    type: String,
    required: true,
    default: "Standard"
  },
  price: {
    type: Number,
    required: true,
    min: 0
  },
  amenities: [{
    type: String
  }],
  isBlocked: {
    type: Boolean,
    default: false
  },
  allowedRoles: [{
    type: String,
    enum: ["USER", "ADMIN", "SUPER_ADMIN"],
    default: ["USER", "ADMIN", "SUPER_ADMIN"]
  }],
  description: {
    type: String,
    default: ""
  },
  capacity: {
    type: Number,
    default: 1,
    min: 1
  }
}, { timestamps: true });

module.exports = mongoose.model("Room", roomSchema);
