const mongoose = require("mongoose");

const paymentSchema = new mongoose.Schema({
  bookingId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Booking",
    required: true
  },
  amount: {
    type: Number,
    required: true
  },
  method: {
    type: String,
    enum: ["RAZORPAY", "CASH", "UPI", "BANK_TRANSFER"],
    required: true
  },
  status: {
    type: String,
    enum: ["PENDING", "PAID", "FAILED", "REFUNDED"],
    default: "PENDING"
  },
  transactionRef: String,     // Razorpay payment id / UTR / slip no
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User"
  },
  proofUrl: String
}, { timestamps: true });

module.exports = mongoose.model("Payment", paymentSchema);
  